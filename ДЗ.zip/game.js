    const boxes = $('.box-zone img');
    const winIndex = Math.floor(Math.random() * boxes.length);
    const attemptsSpan = $('#attempts');
    const showButton = $('#show');
    const closeBlock = $('.close-block');
    const endTitle = $('#end-title');
    let attempts = 5;
    attemptsSpan[0].textContent = attempts;


    function endGame() {
        closeBlock[0].classList.add('active');
    }

    
    for (let i = 0; i < boxes.length; i++) {
        boxes[i].addEventListener('click', function() {

            if (this.classList.contains('empty')) {
                return;
            }
            if (this === boxes[winIndex]) {
                this.src = './img/diamond.jpg';
                endTitle[0].textContent = 'Вы победили!!!';
                endGame();
            } else {
                this.src = './img/cross.jpg';
                    
                this.classList.add('empty');
                attemptsSpan[0].textContent = --attempts;
            }
            if (attempts === 0) {
                endTitle[0].textContent = 'Вы проиграли... Но вы можете попробовать снова!';
                endGame();
            }
        });
    }
    showButton[0].addEventListener('click', function() {
        boxes[winIndex].src = './img/diamond.jpg';
        endTitle[0].textContent = 'Проверил?';
        endGame();
    });
