var gameActivator = $('.copyright a');
var times = 0;
gameActivator[0].addEventListener('click', function() {
    times++;
    console.log('click');
    if (times === 4) {
        gameActivator[0].outerHTML = '<a href=\"./game.html\" id=\"secret\"><h2>©by Lazaret</h2></a>';
    }
});
