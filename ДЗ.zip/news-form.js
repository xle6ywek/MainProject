        var title = document.getElementById('news-name');
        var desc = document.getElementById('desc');
        var date = document.getElementById('date');
        var topic = document.getElementById('topic');
        var tel = document.getElementById('tel');
        var suggestedNews = document.querySelector('.suggested-news');
        
        $('form')[0].addEventListener('submit', function(e) {
            e.preventDefault();
            console.log(title.value);
            console.log(date.value);
            console.log(topic.value);
            console.log(desc.value);
            console.log(tel.value);

            var h2 = document.createElement('h2');
            h2.textContent = title.value;
            console.log(h2);

            var p = document.createElement('p');
            p.textContent = desc.value;
            console.log(p);

            var topicP = document.createElement('p');
            topicP.textContent = topic.value;
            console.log(topicP);


            var dateSpan = document.createElement('span');
            dateSpan.textContent = date.value;
            console.log(dateSpan);

            var li = document.createElement('li');
            li.append(h2);
            li.append(p);
            li.append(dateSpan);
            li.append(topicP)
            console.log(li);

            suggestedNews.append(li);
            li.classList.add(topic.value, 'new-task');
        });